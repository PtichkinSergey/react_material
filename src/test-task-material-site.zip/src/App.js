import {Button, Container, Typography, Grid} from '@mui/material';
import AppBarComp from './AppBarComp';
import GridCardComp from './GridCardComp';
import MainPaper from './MainPaper';
import './App.css'

export default function App(){
  return (
    <>
    <AppBarComp/>
    <main>
      <MainPaper/>
      <div>
        <Container maxWidth = "md">
          <Typography variant='h5' align='center' color="textSecondary" paragraph>
            В нашем сервисе можно найти курсы по самым различным тематикам.
            Обучение в каждом из них построено по актуальным материалам.
            Сервис постоянно улучшается и пополняется.
          </Typography>
          <Typography variant='h2' align='center' color="textPrimary" gutterBottom>Подборка курсов</Typography>
        </Container>
      </div>
      <GridCardComp/>
    </main>
    <div className='bottomGrid'>
        <Grid container spacing={2} justifyContent = "center">
          <Grid item>
            <Button variant='contained' color='primary'>Больше курсов</Button>
          </Grid>
          <Grid item>
            <Button variant='outlined' color='primary'>Сообщить о проблеме</Button>
          </Grid>
        </Grid>
    </div>
    <Typography align='center' color='textSecondary' component='p' variant='subtitle1'>
      20.10.2022 LETI FKTI Ptichkin S.A.
    </Typography>
    </>
  );
}
