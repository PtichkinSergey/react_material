import {Dialog, DialogTitle, DialogContent, DialogContentText, TextField, DialogActions, Button, Checkbox, FormGroup, FormControlLabel} from '@mui/material';
import React from 'react';
import './App.css'

export default class DialogSignUp extends React.Component {
    constructor(props){
        super(props)
        this.state = {
            
        }
    }
    render(){ 
        return (
            <Dialog open={this.props.is_open} onClose={this.props.func} aria-labelledby="form-dialog-title">
                <DialogTitle id="form-dialog-title">Регистрация</DialogTitle>
                <DialogContent>
                    <DialogContentText>Зарегистрируйтесь, чтобы начать обучение</DialogContentText>
                    <TextField
                        autoFocus={true}
                        margin='dense'
                        id='name'
                        label="Email Adress"
                        type="email"
                        fullWidth
                    />
                    <TextField
                        margin='dense'
                        id='pass'
                        label="Пароль"
                        type="password"
                        fullWidth
                    />
                    <TextField
                        margin='dense'
                        id='repPass'
                        label="Повторите пароль"
                        type="password"
                        fullWidth
                    />
                    <FormGroup>
                        <FormControlLabel control={<Checkbox color='success'/>} label='Запомнить меня?'/>
                    </FormGroup>
                </DialogContent>
                <DialogActions>
                    <Button onClick={this.props.func} color="success" variant="contained">Зарегистрироваться</Button>
                    <Button onClick={this.props.func} color="error" variant="outlined">Отмена</Button>
                </DialogActions>
            </Dialog>
        );
    }
}
