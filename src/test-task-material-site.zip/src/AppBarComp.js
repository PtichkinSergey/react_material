import { AppBar, Button, Container, IconButton, Toolbar, Typography, Select, InputLabel, MenuItem, FormControl} from '@mui/material'
import {Component} from 'react';
import './App.css'
import { Box } from '@mui/system';
import MenuIcon from '@mui/icons-material/Menu'
import DialogLogIn from './DialogLogIn';
import DialogSignUp from './DialogSignUp';


export default class AppBarComp extends Component{
    constructor(props){
        super(props)
        this.state = {
          log_in_dialog: false,
          sign_up_dialog: false,
          localisation: 'RU'
        }
        this.handleLogInOpen = this.handleLogInOpen.bind(this)
        this.handleLogInClose = this.handleLogInClose.bind(this)
        this.handleSignUpOpen = this.handleSignUpOpen.bind(this)
        this.handleSignUpClose = this.handleSignUpClose.bind(this)
        this.handleLocalChange = this.handleLocalChange.bind(this)
    }
    handleLogInOpen(){
        this.setState({
          log_in_dialog: true
        });
    }
    handleLogInClose(){
        this.setState({
          log_in_dialog: false
        });
    }
    handleSignUpOpen(){
      this.setState({
        sign_up_dialog: true
      });
    }
    handleSignUpClose(){
      this.setState({
        sign_up_dialog: false
      });
    }
    handleLocalChange(value){
      this.setState({
        localisation: value
      });
    }
    render(){
        return(
        <div className="App">
          <AppBar position='fixed'>
            <Container fixed>
              <Toolbar>
                <IconButton edge = "start" color = "inherit" aria-label = "menu" className='menuButton'>
                  <MenuIcon/>
                </IconButton>
                <Typography variant='h6' className='title' align='left'>LetiCources</Typography>
                <Box mr={3}>
                  <Button variant='outlined' color='inherit' onClick={this.handleLogInOpen}>Log in</Button>
                  <DialogLogIn is_open = {this.state.log_in_dialog} func={this.handleLogInClose}/>
                </Box>
                <Box mr={3}>
                  <Button color='secondary' variant='contained' align='right' onClick={this.handleSignUpOpen}>Sign Up</Button>
                  <DialogSignUp is_open = {this.state.sign_up_dialog} func={this.handleSignUpClose}/>
                </Box>
                <FormControl sx={{ m: 1, minWidth: 120 }} size="small" align='right'>
                  <InputLabel id="localisation-select-label">Lang</InputLabel>
                  <Select
                    labelId="localisation-select-label"
                    id="localisation-select-label"
                    value={this.localisation}
                    label="Localisation"
                    onChange={this.handleChange}
                  >
                    <MenuItem value={'RU'}>RU</MenuItem>
                    <MenuItem value={'ENG'}>ENG</MenuItem>
                  </Select>
                </FormControl>
              </Toolbar>
            </Container>
          </AppBar>
        </div>
    );
    }
}