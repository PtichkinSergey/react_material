import {Dialog, DialogTitle, DialogContent, DialogContentText, TextField, DialogActions, Button, FormGroup, FormControlLabel, Checkbox} from '@mui/material';
import React from 'react';
import './App.css'

export default class DialogLogIn extends React.Component {
    constructor(props){
        super(props)
        this.state = {
            
        }
    }
    render(){ 
        return (
            <Dialog open={this.props.is_open} onClose={this.props.func} aria-labelledby="form-dialog-title">
                <DialogTitle id="form-dialog-title">Log in</DialogTitle>
                <DialogContent>
                    <DialogContentText>Log in to gain knowledge</DialogContentText>
                    <TextField
                        autoFocus={true}
                        margin='dense'
                        id='name'
                        label="Email Adress"
                        type="email"
                        fullWidth
                    />
                    <TextField
                        margin='dense'
                        id='pass'
                        label="Password"
                        type="password"
                        fullWidth
                    />
                    <FormGroup>
                        <FormControlLabel control={<Checkbox color='success'/>} label='Запомнить меня?'/>
                    </FormGroup>
                </DialogContent>
                <DialogActions>
                    <Button onClick={this.props.func} color="success" variant="contained">Log in</Button>
                    <Button onClick={this.props.func} color="error" variant="outlined">Cancel</Button>
                </DialogActions>
            </Dialog>
        );
    }
}
