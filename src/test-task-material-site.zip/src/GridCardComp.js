import {Grid, Card, CardMedia, CardContent, Typography, Button, Container, CardActions} from '@mui/material';
import './App.css'

function GridCardComp(){
  const cards = [1,2,3,4,5,6,7,8,9]
    return (
        <Container maxWidth="md" className="cardGrid">
            <Grid container spacing={4}>
              {cards.map((card)=>(
                <Grid item key = {card} xs="12" sm="6" md="4">
                  <Card className='card'>
                    <CardMedia
                      className='cardMedia'
                      image="https://source.unsplash.com/random"
                      title="Image title"
                    />
                    <CardContent className="cardContent">
                      <Typography variant='h5' gutterBottom>
                        Онлайн курс
                      </Typography>
                      <Typography>
                        Описание онлайн курса
                      </Typography>
                    </CardContent>
                    <CardActions>
                      <Button size="small" variant="contained" color="success">
                        Начать
                      </Button>
                      <Button size="small" color="primary">
                        Info
                      </Button>
                    </CardActions>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </Container>  
    );
}

export default GridCardComp;