import {Button, Container, Paper, Typography, Grid} from '@mui/material';

export default function MainPaper(){
    return(
        <Paper 
        className='mainFeaturePost'
        style={{backgroundImage: `url(https://source.unsplash.com/random)`}}
      >
        <Container fixed>
          <div className='overlay'/>
          <Grid container>
            <Grid item md={8}>
              <div className='mainFeaturePostContent'>
                <Typography component="h1" variant='h3' color='white' gutterBottom>
                  О нашем сервисе
                </Typography>
                <Typography variant="h5" color='white' paragraph>
                  Новейшие программы обучения от опытных специалистов.
                  Множество различных тематик, где каждый найдёт для себя что-то новое.
                  Один из лучших сервисов для бесплатного обучения. 
                </Typography>
                <Button variant='contained' color='secondary'>Узнать больше</Button>
              </div>
            </Grid>
          </Grid>
        </Container>
      </Paper>
    );
}